{{/*
Chart name (override-aware).
*/}}
{{- define "allure-server.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Fully qualified app name. Used for every resource this chart creates — makes the
chart sub-chart / multi-release safe.
*/}}
{{- define "allure-server.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Chart label value.
*/}}
{{- define "allure-server.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels (attached to every resource).
*/}}
{{- define "allure-server.labels" -}}
helm.sh/chart: {{ include "allure-server.chart" . }}
{{ include "allure-server.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels (must be stable across upgrades — do NOT add version here).
*/}}
{{- define "allure-server.selectorLabels" -}}
app.kubernetes.io/name: {{ include "allure-server.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
ServiceAccount name to use on the pod.
*/}}
{{- define "allure-server.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "allure-server.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Headless service name (stable DNS for StatefulSet).
*/}}
{{- define "allure-server.headlessServiceName" -}}
{{- printf "%s-headless" (include "allure-server.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
DB CA ConfigMap name.
*/}}
{{- define "allure-server.crtConfigMapName" -}}
{{- printf "%s-crt" (include "allure-server.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Static env vars from `.Values.env` (map → list of {name,value}).
*/}}
{{- define "allure-server.staticEnv" -}}
{{- range $k, $v := .Values.env -}}
- name: {{ $k }}
  value: {{ $v | quote }}
{{ end -}}
{{- end }}

{{- define "allure-server.secretEnv" -}}
{{- $defaultSecret := .Values.secretEnv.secretName -}}
{{- range $item := .Values.secretEnv.keys -}}
{{- if kindIs "string" $item -}}
- name: {{ $item }}
  valueFrom:
    secretKeyRef:
      name: {{ required "secretEnv.secretName must be set when using string-form keys" $defaultSecret }}
      key: {{ $item }}
{{ else -}}
- name: {{ $item.name | required "secretEnv.keys[].name is required" }}
  valueFrom:
    secretKeyRef:
      name: {{ default $defaultSecret $item.from | required "secretEnv.keys[].from or secretEnv.secretName must be set" }}
      key: {{ default $item.name $item.key }}
{{ end -}}
{{- end -}}
{{- end }}

{{/*
Render a probe body (without timing fields). Args: dict with "probe" and "root".

Probe type is picked from the shared default `.Values.probes.type` unless the
specific probe overrides it via its own `type` field. Supported values:
  - "httpGet" (default): classic HTTP probe, with optional static httpHeaders.
  - "exec":    runs wget/curl from inside the container, can read creds from env.

Both modes pick `path` from probe-level then from shared default.
*/}}
{{- define "allure-server.probeBody" -}}
{{- $probe := .probe -}}
{{- $root := .root -}}
{{- $type := default (default "httpGet" $root.probes.type) $probe.type -}}
{{- $path := default (default "/api/result" $root.probes.path) $probe.path -}}
{{- if eq $type "exec" -}}
{{- $exec := $probe.exec -}}
{{- if not $exec -}}{{- $exec = $root.probes.exec -}}{{- end -}}
{{- if $exec }}
exec:
  {{- toYaml $exec | nindent 2 }}
{{- else -}}
{{/* default exec: BusyBox wget with optional Basic Auth via env vars */}}
{{- $port := $root.service.port | int -}}
{{- $probeAuth := default (dict) $probe.basicAuth -}}
{{- $rootAuth := default (dict) $root.probes.basicAuth -}}
{{- $authUserVar := default $rootAuth.usernameEnv $probeAuth.usernameEnv | default "BASIC_AUTH_USER" -}}
{{- $authPassVar := default $rootAuth.passwordEnv $probeAuth.passwordEnv | default "BASIC_AUTH_PASS" -}}
exec:
  command:
    - sh
    - -c
    - |
      set --
      if [ -n "${{"{"}}{{ $authUserVar }}{{"}"}}" ]; then
        token=$(printf '%s:%s' "${{"{"}}{{ $authUserVar }}{{"}"}}" "${{"{"}}{{ $authPassVar }}{{"}"}}" | base64 | tr -d '\n')
        set -- --header="Authorization: Basic $token"
      fi
      exec wget -q -O /dev/null "$@" "http://127.0.0.1:{{ $port }}{{ $path }}"
{{- end }}
{{- else -}}
httpGet:
  path: {{ $path }}
  port: http
  {{- $headers := default $root.probes.httpHeaders $probe.httpHeaders }}
  {{- if $headers }}
  httpHeaders:
    {{- toYaml $headers | nindent 4 }}
  {{- end }}
{{- end -}}
{{- end }}


