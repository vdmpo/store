# allure-server

Helm chart for [Allure Server](https://github.com/kochetkov-ma/allure-server).

Compatible with Kubernetes **>= 1.25** (tested on 1.32). Workload is a
`StatefulSet` with `volumeClaimTemplates` — safe for stateful storage.

## Install

```bash
helm install allure ./allure-server -f my-values.yaml
```

## Use as sub-chart

Add to your parent `Chart.yaml`:

```yaml
dependencies:
  - name: allure-server
    version: 2.0.0
    repository: file://./charts/allure-server  # or a helm repo URL
```

Override values under the `allure-server:` key in the parent `values.yaml`.
All resources are named via `fullname` (`<release>-allure-server` by default),
so multiple releases in one namespace don't collide.

## Env vars

Three independent mechanisms, you can combine them:

**1. Static values — `env`:**

```yaml
env:
  SPRING_PROFILES_ACTIVE: prod
  SPRING_DATASOURCE_URL: jdbc:postgresql://db:5432/allure
```

**2. Specific keys from a Secret — `secretEnv`:**

```yaml
secretEnv:
  secretName: allure-db
  keys:
    - SPRING_DATASOURCE_USERNAME
    - SPRING_DATASOURCE_PASSWORD
    # Or pull from a different secret / remap the key:
    - name: SPRING_DATASOURCE_URL
      from: allure-db-url
      key: jdbc-url
```

**3. Whole Secret / ConfigMap via `envFrom`:**

```yaml
envFrom:
  - secretRef:
      name: allure-server-secrets
  - configMapRef:
      name: allure-server-extra-config
```

Secrets and ConfigMaps referenced above **must be created separately** (the
chart does not create them — use Vault / SealedSecrets / ExternalSecrets).

## Persistence

Enabled by default via `volumeClaimTemplates`:

```yaml
persistence:
  enabled: true
  storageClassName: gp3           # empty → cluster default
  size: 10Gi
  accessModes: [ReadWriteOnce]
  mountPath: /allure
```

Set `persistence.enabled: false` to fall back to an `emptyDir`.

## Ingress

```yaml
ingress:
  enabled: true
  className: nginx
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-prod
    nginx.ingress.kubernetes.io/proxy-body-size: 100m
  hosts:
    - host: allure.example.com
      paths:
        - path: /
          pathType: Prefix
  tls:
    - hosts: [allure.example.com]
      secretName: allure-tls
```

Annotations are empty by default — nothing will pollute your merged values.
