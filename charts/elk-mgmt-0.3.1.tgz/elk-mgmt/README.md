## ELK Setup Helm Chart

A chart manages ELK resources (e.g. ILM, Temlates, Index Patterns)

Example: Check file `values.yaml.example` for details.
