# Elasticsearch 8x Helm Chart

Custom Chart (based on 7.17.x):

1) Removed node.ml role (doesn't exist in 8x)
2) Changed imageTag
3) Changed podsecuritypolicy.yaml
4) RBAC to create secrets